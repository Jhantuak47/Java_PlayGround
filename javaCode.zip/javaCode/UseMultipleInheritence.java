package com.trainingcore2.java;

public class UseMultipleInheritence {
	
	public static void main(String[] args) {
		
		Manager obm = new Manager();
		Instructur objI = new Manager();
		Employee obj2 = new Manager();
		
		objI.enjoy();
		obj2.enjoy();
	}

}
